#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

# Write your classes here


class Player:
    """
    A player in the game
    """

    def __init__(self, name):
        """
        Construct a player in the game from the players name.  Generates an empty hand deck and empty coders deck

        Parameters:
            name (str): The name of the player
        """
        self._name = name
        self._hand: Deck = Deck()
        self._coders: Deck = Deck()

    def get_name(self):
        """
        Returns the players name.

        Returns:
            (str): The players name.
        """
        return self._name

    def get_hand(self):
        """
        Returns the players hand.

        Returns:
            (Deck): A deck object representing the players hand
        """
        return self._hand

    def get_coders(self):
        """
        Returns the players awakened coders

        Returns:
            (Deck): A deck object representing the players awakened coders
        """
        return self._coders

    def has_won(self):
        """
        Determines whether the player has won by collecting the required number of coders

        Returns:
            (bool): Whether the player has won or not
        """
        coders_required_for_win = 4
        return self._coders.get_amount() >= coders_required_for_win

    def __str__(self):
        return 'Player(' + self._name + ', ' + str(self._hand) + ', ' + str(self._coders) + ')'

    def __repr__(self):
        return self.__str__()


class Card:
    """
    Base class for a card
    """

    # Constants for the game actions
    NO_ACTION = "NO_ACTION"
    PICKUP_CODER = "PICKUP_CODER"
    STEAL_CODER = "STEAL_CODER"
    SLEEP_CODER = "SLEEP_CODER"

    _name = None

    def play(self, player: Player, game):
        """
        Plays the card selected from the players hand, picks up a card from the pickup pile to replace the
        card played and sets the default action

        Parameters:
            player (Player): the player who played the card
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        # Finds the index in the list of the players hand, then removes the card from that index.
        slot = player.get_hand().get_cards().index(self)
        player.get_hand().remove_card(slot)

        # Add new card to hand
        new_card = game.pick_card()[0]
        player.get_hand().add_card(new_card)
        game.get_pickup_pile().remove_card(-1)

        game.set_action(self.NO_ACTION)

    def action(self, player: Player, game, slot: int):
        """
        Performs the action of the special card.  This method is a placeholder for the derived classes

        Parameters:
            player (Player): A player, dependent on which special card was played and what card selected.
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
            slot (int): The index of the card selected in the decks card list of the given player.
        """
        pass

    def get_name(self):
        """
        Get the name of the card, for the cards that have names

        Returns:
            (str): The name of the card
        """
        return self._name

    def end_turn(self, game):
        """
        Ends the current turn by setting action to 'NO_ACTION' and moving the game to the next player.
        """
        game.set_action(self.NO_ACTION)
        game.next_player()

    def pick_coder_card(self, coders, slot, replace_with_none: bool = False):
        """
        Returns the coder card at the given slot in the given coder card list.  Remove the card from the coders
        list and replace with None if specified

        Parameters:
            coders (List[Card]): The list of coder cards to get the specified coder
            slot (int): The index of the coder card required
            replace_with_none (bool): Whether to replace the card at the given slot (index) with None (True)
                                        or to just remove it from the list (False, default)

        Returns:
            (Card): The coder card found in the list of coders at the given slot
        """
        coder = coders[slot]
        if not replace_with_none:
            coders.pop(slot)
        else:
            coders[slot] = None
        return coder

    def __str__(self):
        return 'Card()'

    def __repr__(self):
        return self.__str__()


class NumberCard(Card):
    """
    A number card
    """

    def __init__(self, number):
        """
        Construct a number card of the given number.

        Parameters:
            number (int): The number for the number card
        """
        self._number = number

    def get_number(self):
        """
        Get the number of the number card

        Returns:
            (int): The number of the number card
        """
        return self._number

    def play(self, player: Player, game):
        """
        Overrides and supplements the play method from the base class.  Runs the base method and then
        moves the game to the next players turn.

        Parameters:
            player (Player): The player that played the number card
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        super().play(player, game)
        self.end_turn(game)

    def __str__(self):
        return 'NumberCard(' + str(self._number) + ')'

    def __repr__(self):
        return self.__str__()


class CoderCard(Card):
    """
    A coder card
    """

    def __init__(self, name):
        """
        Construct a coder card with the given name.

        Parameters:
            name (str): The name of the coder card
        """
        self._name = name

    def play(self, player: Player, game):
        """
        Overrides the play method from the base class.  Sets the action to 'NO_ACTION'.

        Parameters:
            player (Player): A player in the game.  Not used in this method
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        game.set_action(self.NO_ACTION)

    def __str__(self):
        return 'CoderCard(' + self._name + ')'

    def __repr__(self):
        return self.__str__()


class TutorCard(Card):
    """
    A tutor card
    """

    def __init__(self, name):
        """
        Construct a tutor card with the given name.

        Parameters:
            name (str): The name of the tutor card
        """
        self._name = name

    def play(self, player: Player, game):
        """
        Overrides and supplements the play method from the base class.  Runs the base method and then
        sets the action to 'PICKUP_CODER'.

        Parameters:
            player (Player): The player that played the tutor card
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        super().play(player, game)
        game.set_action(self.PICKUP_CODER)

    def action(self, player: Player, game, slot: int):
        """
        Performs the action of the tutor card (awakening a sleeping coder) by removing it from the deck of
        sleeping coders and putting it into the players 'coders' deck.  Set action back to 'NO_ACTION' and
        move the game to the next player.

        Parameters:
            player (Player): The player who played the tutor card.
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
            slot (int): The index of the card in the sleeping coders deck.cards list.
        """
        coder = self.pick_coder_card(game.get_sleeping_coders(), slot, True)
        player.get_coders().add_card(coder)

        self.end_turn(game)

    def __str__(self):
        return 'TutorCard(' + self._name + ')'

    def __repr__(self):
        return self.__str__()


class KeyboardKidnapperCard(Card):
    """
    A keyboard kidnapper card
    """

    def play(self, player: Player, game):
        """
        Supplements the play method from the base class.  Runs the base method and then
        sets the action to 'STEAL_CODER'.

        Parameters:
            player (Player): The player that played the keyboard kidnapper card
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        super().play(player, game)
        game.set_action(self.STEAL_CODER)

    def action(self, player: Player, game, slot: int):
        """
        Performs the action of the keyboard kidnapper card (stealing an awoken coder) by removing the coder from
        its current owners coders deck and putting it into the current players coders deck.  Set the action back
        to 'NO_ACTION' and move the game to the next player.

        Parameters:
            player (Player): The player who owns the coder card to be stolen.
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
            slot (int): The index of the coder card in its owners coders deck.cards list.
        """
        coder = self.pick_coder_card(player.get_coders().get_cards(), slot)
        game.current_player().get_coders().add_card(coder)

        self.end_turn(game)

    def __str__(self):
        return 'KeyboardKidnapperCard()'

    def __repr__(self):
        return self.__str__()


class AllNighterCard(Card):
    """
    An all nighter card
    """

    def play(self, player: Player, game):
        """
        Supplements the play method from the base class.  Runs the base method and then
        sets the action to 'SlEEP_CODER'.

        Parameters:
            player (Player): The player that played the all nighter card.
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
        """
        super().play(player, game)
        game.set_action(self.SLEEP_CODER)

    def action(self, player: Player, game, slot: int):
        """
        Performs the action of the all nighter card (putting a coder back to sleep) by removing the coder from
        its current owners coders deck and putting it into the first available slot in the sleeping coders deck.
        Set the action back to 'NO_ACTION' and move the game to the next player.

        Parameters:
            player (Player): The player who owns the coder card to be put back to sleep.
            game (a2_support.CodersGame): The model for the current game of Sleeping Coders
            slot (int): The index of the coder card in its owners coders deck.cards list.
        """
        coder = self.pick_coder_card(player.get_coders().get_cards(), slot)

        # Find first position in sleeping coders deck.cards list where there is no sleeping coder.  Add coder
        # to that spot
        pos = game.get_sleeping_coders().index(None)
        game.set_sleeping_coder(pos, coder)

        self.end_turn(game)

    def __str__(self):
        return 'AllNighterCard()'

    def __repr__(self):
        return self.__str__()


class Deck(object):
    """
    A class to store the list of cards for a given location on the board.
    """

    def __init__(self, starting_cards=None):
        """
        Constructs an instance of a deck based on a starting list of cards

        Parameters:
            starting_cards (List[Cards]): The list of cards to include in the deck
        """
        if starting_cards is None:
            starting_cards = []
        self._deck = starting_cards

    def get_cards(self):
        """
        Returns the list of cards in the deck

        Returns:
            (List[Card]): The list of cards in the deck
        """
        return self._deck

    def get_card(self, slot):
        """
        Returns a specific card in the deck

        Parameters:
            slot (int): the index of the card to return

        Returns:
            (Card): The card at the given slot.
        """
        return self._deck[slot]

    def top(self):
        """
        Returns the card at the top of the deck

        Returns:
            (Card): The card at the top of the deck
        """
        return self._deck[-1]

    def remove_card(self, slot):
        """
        Removes the card from the specified slot

        Parameters:
            slot (int): the index of the card in the deck to be removed
        """
        self._deck.pop(slot)

    def get_amount(self):
        """
        Returns the number of cards in the deck

        Returns:
            (int): The number of cards in the deck
        """
        return len(self._deck)

    def shuffle(self):
        """
        Shuffles the deck
        """
        random.shuffle(self._deck)

    def pick(self, amount: int = 1):
        """
        Gets the specified number of cards from the top of the deck, removing them from the deck.

        Parameters:
            amount (int): The number of cards to be returned

        Returns:
            (List[Card]): The cards taken from the top of the deck
        """
        i = 1
        picked = []
        while i <= amount:
            picked.append(self._deck.pop(-1))
            i += 1
        return picked

    def add_card(self, card: Card):
        """
        Adds the provided card to the top of the deck

        Parameters:
            card (Card): The card to be added to the deck
        """
        self._deck.append(card)

    def add_cards(self, cards: [Card]):
        """
        Adds the provided list of cards to the top of the deck

        Parameters:
            cards (List[Card]): The list of cards to be added to the deck
        """
        self._deck = self._deck + cards

    def copy(self, other_deck):
        """
        Appends the cards in the provided deck to the current decks list of cards

        Parameters:
            other_deck (Deck): The deck to be added to the current deck
        """
        self._deck = self._deck + other_deck.get_cards()

    def __str__(self):
        return 'Deck(' + str(self.get_cards()).strip('[]') + ')'

    def __repr__(self):
        return self.__str__()


def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
