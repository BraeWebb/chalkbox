#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

# Write your classes here
class Player(object):
    """
    Represents a player in the game
    """
    def __init__(self, name):
        """
        constructs a player with given name and an empty hand of cards and empty set of coders cards.
        parameters:
        name (str): name of player
        """
        self._name = name
        self._hand = Deck()
        self._coders = Deck()

    def __str__(self):
        """
        string representation
        """
        return "Player("+self._name+", " + str(self._hand) + ", " + str(self._coders) + ")"

    def __repr__(self):
        """
        representation
        """
        return str(self)

    def get_name(self):
        """
        (str) return the name of the player
        """
        return self._name

    def get_hand (self):
        """
        (list<Card>) return the players hand of cards as a list
        """
        return self._hand

    def set_hand(self, new_hand):
        """
        sets the input list as the new hand for player
        parameters:
        (list<Card>): new hand of cards
        """
        self._hand = new_hand[:]

    def get_coders(self):
        """
        (list<Card>)returns the coder cards belonging to the player.
        """
        return self._coders

    def add_coder(self, card):
        """
        adds a coder to the pack.
        parameters:
        (Card) the new coder to add
        """
        self._coders.add_card(card)

    def has_won(self):
        """
        (boolean) returns whether a player has enough coder cards to win.
        """
        if self._coders.get_amount() >= 4:
            return True
        else:
            return False

    def remove_card_from_hand(self, card):
        """
        removes input card from the players hand.
        parameter:
        (card) the card to remove
        """
        self._hand.remove(card)

    def pickup_new_card(self, game):
        """
        picks up a card from the pickup pile
        parameters:
        (game) the game object contianing the pickup deck.
        """
        self._hand.add_card(game.pick_card()[0])

class Deck(object):
    """
    A deck of cards.
    """
    def __init__(self, starting_cards=None):
        """
        initialise a Deck.
        parameters:
        (list<cards>) optional list of cards to start the deck with,
        otherwise the deck will start as empty
        """
        self._cards = []
        if starting_cards != None:
            for card in starting_cards:
                self._cards.append(card)

    def get_card(self, slot):
        """
        (card) returns the card at position
        parameters:
        (int) the slot position in question
        """
        return self._cards[slot]

    def get_cards(self):
        """
        (list<cards>) returns the current cards in a deck
        """
        return self._cards

    def top(self):
        """
        (card) returns the top card in the deck
        """
        return self._cards[-1]

    def remove_card(self, slot):
        """
        removes the card at slot position from the deck
        parameters:
        (int) the position of the card to remove
        """
        self._cards.pop(slot)

    def get_amount(self):
        """
        (nt) returns the number of cards in the deck
        """
        return len(self._cards)

    def shuffle(self):
        """
        shuffles in place the deck of cards
        """
        random.shuffle(self._cards)

    def pick(self, amount=1):
        """
        picks a number of cards from the deck and returns a list of these cards.
        parameters:
        (int) the number of cards to pick
        """
        picks = []
        i = 0
        while i < amount:
            picks.append(self._cards.pop())
            i += 1
        return picks

    def add_card(self, card):
        """
        takes a card and adds it to the deck
        Parameters:
        (Card) card to add
        """
        self._cards.append(card)

    def add_cards(self, cards):
        """
        takes a list of cards and adds them to the deck
        Parameters:
        (list[Cards]) new cards to add
        """
        self._cards.extend(cards)

    def copy(self, deck):
        """
        takes all the cards in input deck and adds them to the current object
        parameters:
        (Deck) the deck of cards to copy across
        """
        self.add_cards(deck.get_cards())

    def __str__(self):
        """
        string representation
        """
        string = "Deck("
        flag = False
        for i in self._cards:
            if flag == True:
                string += ", "
            flag = True
            string += str(i)
        string += ")"
        return string

    def __repr__(self):
        """
        representation
        """
        return str(self)

class Card(object):
    """
    Represents a card
    """
    def __init__(self):
        """
        Construct a card
        """
        self._type = "Card"
        self._value = ""
        self._action = "NO_ACTION"

    def __str__(self):
        """
        string representation
        """
        return self._type+"("+str(self._value)+")"

    def __repr__(self):
        """
        representation
        """
        return self._type+"("+str(self._value)+")"

    def get_action(self):
        """
        (str) returns the action associated with card
        """
        return self._action

    def play(self, player, game):
        """
        play function for Card object. removes card from hand
        sets action and picks up next card.
        parameters:
        (player) the current player
        (game) the current game
        """
        player.get_hand().get_cards().remove(self)
        game.set_action(self.get_action())
        player.pickup_new_card(game)

    def action(self, player, game, slot):
        """
        general action for Card class
        Parameters:
        (player) current player
        (game) current game
        (slot) slot choice
        """
        pass

class NumberCard(Card):
    """
    extends Card class to for NumberCard instance
    """
    def __init__(self, number):
        """
        constructs NumberCard object
        Parameters:
        (int) the number value of the card
        """
        self._action = "NO_ACTION"
        self._number = number
        self._value = number
        self._type = "NumberCard"

    def get_number(self):
        """
        (int) returns the number value of the card
        """
        return self._number

    def play(self, player, game):
        """
        sets action. discards card. pickup card. go to next player.
        """
        game.set_action(self.get_action())
        player.get_hand().get_cards().remove(self)
        player.pickup_new_card(game)
        game.next_player()

    def action(self, player, game, slot):
        """
        action passes
        """
        pass

class CoderCard(Card):
    """
    CoderCard class extension of Card class.
    """
    def __init__(self, name):
        """
        constructs an instance of CoderCard
        """
        super().__init__()
        self._value = name
        self._type = "CoderCard"
        self._name = name

    def get_name(self):
        """
        Returns the name of the CoderCard
        """
        return self._name

    def play(self, player, game):
        """
        private play function. simply sets action.
        """
        game.set_action(self.get_action())
        pass

class TutorCard(Card):
    """
    TutorCard extends Card class
    """
    def __init__(self, name):
        """
        Constructs TutorCard
        parameters:
        (str) name of card
        """
        super().__init__()
        self._value = name
        self._type = "TutorCard"
        self._name = name
        self._action = "PICKUP_CODER"

    def get_name(self):
        """
        Returns name of card
        """
        return self._name

    def action(self, player, game, slot):
        """
        Action for TutorCard.
        picks card from sleeping queen pile.
        sets this sleeping coder to None.
        sets action.
        moves to next player.
        parameters:
        (player)
        (game) the game
        (slot) the sleeping queen slot to take.
        """
        new_card = game.get_sleeping_coder(slot)
        game.current_player().get_coders().add_card(new_card)
        game.set_sleeping_coder(slot, None)
        game.set_action("NO_ACTION")
        game.next_player()


class AllNighterCard(Card):
    """
    AllNighterCard class
    """
    def __init__(self):
        """
        Constructor
        """
        super().__init__()
        self._type = "AllNighterCard"
        self._value = ""
        self._action = "SLEEP_CODER"

    def action(self, player, game, slot):
        """
        action function.
        Finds the lowest gap in Sleeping Queens deck and sends the queen
        to that position.
        """
        min_slot = 0
        while game.get_sleeping_coder(min_slot) != None:
            min_slot += 1
        sleeping_queen = player.get_coders().get_card(slot)
        game.set_sleeping_coder(min_slot, sleeping_queen)
        player.get_coders().get_cards().remove(sleeping_queen)
        game.set_action("NO_ACTION")
        game.next_player()

class KeyboardKidnapperCard(Card):
    """
    KeyboardKidnapperCard extends Card
    """
    def __init__(self):
        """
        constructor
        """
        super().__init__()
        self._type = "KeyboardKidnapperCard"
        self._value = ""
        self._action = "STEAL_CODER"

    def play(self, player, game):
        """
        play function sets action, finds slot of target queen to steal.
        takes that card. picks up new card.
        parameters:
        (player): the player whose queen to steal
        (game) the game
        """
        game.set_action(self.get_action())
        slot =game.current_player().get_hand().get_cards().index(self)
        game.current_player().get_hand().remove_card(slot)
        game.current_player().pickup_new_card(game)

    def action(self, player, game, slot):
        """
        action takes card, removes card, sets action and moves to next  player.
        parameters:
        (player) the player to steal from
        (game) the game
        (slot) the slot to steal from
        """
        new_card = player.get_coders().get_card(slot)
        game.current_player().get_coders().add_card(new_card)
        player.get_coders().remove_card(slot)
        game.set_action("NO_ACTION")
        game.next_player()



def main():
    print("Please run gui.py instead")

if __name__ == "__main__":
    main()
