#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

class Card:
    """

    This is a base card that can be overridden by play cards.

    """

    def play(self, player, game):
        """

        Called when player plays a hand.

        Removes card from players hand.

        Picks up a new card from the card pile and adds it to players hand.

        Sets an action if card played requires an action.
            if not action is NO_ACTION

        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        :return: There is no returns!
        """

        # Removing Card
        new_hand = player.get_hand()
        cards_in_hand = new_hand.get_cards()
        cards_in_hand.remove(self)

        # Adds Card
        picked_card = game.pick_card()
        cards_in_hand.extend(picked_card)

        # Set No Action
        game.set_action('NO_ACTION')

    def action(self, player, game, slot):
        """

        Called when a special card is played.

        Tutor Card: select a CODER from the pile

        Keyboard/All-Knighter: selecting a CODER from another player's hand

        ALl other cards do nothing


        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        :param slot(int): position of the selected card
        """
        pass

    def __str__(self):
        """
        :return: String of Class()
        """
        return 'Card()'

    def __repr__(self):
        """

        :return: Same as __str__(self)
        """

        return self.__str__()


class NumberCard(Card):
    """

    Initialises a number card instance

    """

    def __init__(self, number):
        """
        Associated number value

        :param Number: (int) number value
        """

        self._number = number

    def play(self, player, game):
        """

        Game should move on to the next players turn

        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        :return:
        """
        super().play(player, game)

        game.next_player()

    def get_number(self):
        """
        :return: (int) number value of the ard

        """
        return self._number

    def __str__(self):
        """
        :return: (str) NumberCard(instance)

        """
        return "NumberCard({0})".format(self._number)


class CoderCard(Card):
    """

    Initialises a coder card instance.


    """

    def __init__(self, name):
        """
        Stores name of a coder card

        :param name: (str) name of the coder card
        """

        self._name = name

    def play(self, player, game):
        """

        Game should move on to the next players turn

        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        :return:
        """
        game.set_action('NO_ACTION')

    def get_name(self):
        """
        :return: (str) name of the coder card

        """
        return self._name

    def __str__(self):
        """
        :return: (str) 'CoderCard(instance)'

        """
        return "CoderCard({0})".format(self._name)


class TutorCard(Card):
    """

    Initialises a tutor card instance.


    """

    def __init__(self, name):
        """
        Stores name of a tutor card

        :param name: (str) name of the tutor card
        """

        self._name = name

    def play(self, player, game):
        """
        Sets Action to 'PICKUP_CODER'

        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        """
        super().play(player, game)

        game.set_action('PICKUP_CODER')

    def action(self, player, game, slot):
        """

        Gets a Coder Card

        Coder Card added to players deck.

        Position of the card in the sleeping coders' deck should be replaced with None.

        Then the action should be set back to 'NO_ACTION'
        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        :param slot: (int) place of card

        """
        super().action(player, game, slot)

        # Select Coder Card
        coder_card = game.get_sleeping_coder(slot)
        players_coders = player.get_coders()
        coder_card_list = players_coders.get_cards()
        coder_card_list.append(coder_card)

        # Replace sleeping coder card in deck to None
        game.set_sleeping_coder(slot, None)

        # Set No Action
        game.set_action('NO_ACTION')

        # Move on to Next Player
        game.next_player()

    def get_name(self):
        """
        :return: (str) name of the tutor card

        """
        return self._name

    def __str__(self):
        """
        :return: (str) 'TutorCard(instance)'

        """
        return "TutorCard({0})".format(self._name)


class KeyboardKidnapperCard(Card):
    """

    Allows a player to steal a coder card from another player.

    """

    def play(self, player, game):
        """
        Set action to 'STEAL_CODER'
        :param player: instance of Player
        :param game: instance of a2.support.CodersGame
        """

        super().play(player, game)

        game.set_action('STEAL_CODER')

    def action(self, player, game, slot):
        """
        Selected card should be added to the current players deck

        Removed from its origin deck

        set.action to NO_ACTION

        :param player: instance of Player of which the coder belongs to.
        :param game: instance of a2.support.CodersGame
        :param slot: (int) place of card
        """
        super().action(player, game, slot)

        # Stolen Card from Player
        players_coders = player.get_coders()
        stolen_coder = players_coders.get_card(slot)
        players_coders.remove_card(slot)

        # Add to current player
        current_player = game.current_player()
        current_player_coders = current_player.get_coders()
        current_player_coders.add_card(stolen_coder)

        # Set No Action
        game.set_action('NO_ACTION')

        # Move on to next player
        game.next_player()

    def __str__(self):
        """
         :return: (str) 'KeyboardKidnapperCard()'

         """
        return 'KeyboardKidnapperCard()'


class AllNighterCard(Card):
    """

    Allows the player to put a coder card from another player back to sleep.

    """

    def play(self, player, game):
        """
        Set action to 'SLEEP_CODER'

        :param player: instance of Player.
        :param game: instance of a2.support.CodersGame
        """

        super().play(player, game)

        game.set_action('SLEEP_CODER')

    def action(self, player, game, slot):
        """
        Selected Card should be added to the
        first empty slot in the coders pile

        Removed from the origins deck

        Action set back to 'NO_ACTION'

        Move on the player

        :param player: instance of Player of which the coder belongs to.
        :param game: instance of a2.support.CodersGame
        :param slot:
        :return:
        """

        # Select Coder Card
        players_coders = player.get_coders()
        stolen_coder = players_coders.get_card(slot)

        # Add to empty slot in coders pile
        empty_slot = 0
        for x in game.get_sleeping_coders():
            if x is None:
                game.set_sleeping_coder(empty_slot, stolen_coder)
                break
            empty_slot += 1

        # Remove from Origin Deck
        players_coders.remove_card(slot)

        # Set No Action
        game.set_action('NO_ACTION')

        # Move on to next player
        game.next_player()

    def __str__(self):
        """
         :return: (str) 'AllNighterCard()'

         """
        return 'AllNighterCard()'


class Deck:
    """

    A collection of ordered cards.

    """

    def __init__(self, starting_cards=None):
        """
        Initialise a deck

        :param starting_cards: (None) empty list or (list) of cards
        """
        if starting_cards is None:
            self._cards = []
        else:
            self._cards = starting_cards

    def get_cards(self):
        """

        :return: (list) of cards in the deck
        """
        return self._cards

    def get_card(self, slot):
        """

        :param slot: (int) specified slot
        :return: (inst) the card at the specified slot
        """
        return self._cards[slot]

    def top(self):
        """

        :return:(inst) the card on the top of the deck (last added)
        """
        return self._cards[-1]

    def remove_card(self, slot):
        """

        Removes a card at the given slot in a deck

        :param slot: (int) specified slot

        """
        del self._cards[slot]

    def get_amount(self):
        """

        :return: (int) amount of cards in a deck

        """
        return len(self._cards)

    def shuffle(self):
        """

        Shuffles the order of the card of the deck

        """
        random.shuffle(self._cards)

    def pick(self, amount=1):
        """
        Takes the first 'amount' of cards off the deck

        :param amount: (int) a number of cards
        :return: (list) cards of the amount
        """

        taken_cards = self._cards[-amount:]

        self._cards = self._cards[:-amount]

        return list(reversed(taken_cards))

    def add_card(self, card):
        """
        Places a card on top of the deck

        :param card: (inst) instance of a card
        """

        self._cards.append(card)

    def add_cards(self, cards):
        """

        Places a list cards on the top of the deck

        :param cards: (list) of cards
        """
        self._cards.extend(cards)

    def copy(self, other_deck):
        """
        Copies all of the cards from the other_deck into current deck

        Extends the list of cards of the current deck

        :param other_deck: (Deck)

        """

        self._cards.extend(other_deck.get_cards())

    def __str__(self):
        """

        :return: (str) representation of the deck. 'Deck(cardA, CardB, cardC)'

        """
        seperator = ', '

        list_cards = []
        for x in self._cards:
            xstr = str(x)
            list_cards.append(xstr)

        return 'Deck({})'.format(seperator.join(list_cards))

    def __repr__(self):
        """

        :return: (str) same as __str__

        """
        return self.__str__()


class Player:
    """
    One of the players in the game

    """

    def __init__(self, name):
        """
        Initialises a player instance

        :param name: (str) Name of the player
        """
        self._name = name
        self._hand = Deck()
        self._coders = Deck()

    def get_name(self):
        """

        :return: (str) the name of the player

        """
        return self._name

    def get_hand(self):
        """

        :return: (Deck) players deck of cards
        """
        return self._hand

    def get_coders(self):
        """

        :return: (Deck) players deck of collected coder cards
        """
        return self._coders

    def has_won(self):
        """

        :return: (bool) True is and only if the player has 4 or more coders
        """

        x = Deck.get_amount(self._coders)

        if x >= 4:
            return True
        return False

    def __str__(self):
        """
        String representation of the player, for a player with name of
        'Luis', hand deck of 'hand' and coder deck of 'coders',
        :return: (str) 'Player(Luis, hand, coders)'
        """
        return 'Player({0}, {1}, {2})'.format(self._name, self._hand, self._coders)

    def __repr__(self):
        """

        :return: (str) same as __str__

        """
        return self.__str__()


def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
