#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

# Write your classes here
class Player(object):
    """
    Defines the Player Object
    """
    def __init__(self, player_name):
        """
        (str) player_name: the players name
        """
        self._player_name = player_name
        # Deck to hold player's cards
        self._player_deck = Deck()
        # Deck to hold CoderCards
        self._player_coders = Deck()

    def __str__(self):
        return "Player({}, {}, {})".format(self.get_name(), self.get_hand(), self.get_coders())

    def __repr__(self):
        return "Player({}, {}, {})".format(self.get_name(), self.get_hand(), self.get_coders())

    def get_name(self):
        """(str): Returns the player's name"""
        return self._player_name

    def get_hand(self):
        """(Deck): Returns the hand of the player in a Deck object"""
        return self._player_deck

    def get_coders(self):
        """(Deck): Returns the Coder Cards of the player in a Deck object"""
        return self._player_coders

    def has_won(self):
        """(Bool): Returns True if the player has more than 3 coders
        Player wins when they have 4 coder cards
        """
        if len(self.get_coders().get_cards()) > 3:
            return True
        else:
            return False


class Deck(object):
    """Defines the Deck Object"""
    def __init__(self, starting_cards=None):
        """
        (list) starting_cards: a list of starting cards in the deck,
        if no cards, starting_cards = None
        """
        self._starting_cards = starting_cards
        self._player_cards = []
        # Check if starting_cards is a list or None
        # If None, self._starting_cards is None, self._starting_cards = []
        # If a single card is inputted, add that card to a list and input
        if starting_cards is None:
            self._starting_cards = []
        elif type(starting_cards) != list:
            self._starting_cards = list(self._starting_cards)
        else:
            self._starting_cards = starting_cards

    def __str__(self):
        temp_str = ""
        # Check length of of Deck
        # If 0, return only Deck()
        # If > 0, form a string to place inside Deck()
        if len(self._starting_cards) == 0:
            return "Deck()"
        else:
            for card in self._starting_cards:
                temp_str += str(card) + ", "
            temp_str.strip(", ")
            return "Deck({})".format(temp_str.strip(", "))

    def __repr__(self):
        # As in __str__(self)
        temp_str = ""
        if len(self._starting_cards) == 0:
            return "Deck()"
        else:
            for card in self._starting_cards:
                temp_str += str(card) + ", "
            return "Deck({})".format(temp_str.strip(", "))

    def get_cards(self):
        """(list): returns a list of the Deck's cards"""
        return self._starting_cards

    def get_card(self, slot):
        """(Card): returns the specific card in a slot in the deck"""
        return self._starting_cards[slot]

    def top(self):
        """(Card): returns the top most card on a deck"""
        return self._starting_cards[-1]

    def remove_card(self, slot):
        """Removes a card from a specific slot in the Deck"""
        del self._starting_cards[int(slot)]

    def get_amount(self):
        """(int): returns the amount of cards in a deck"""
        return len(self._starting_cards)

    def shuffle(self):
        """Shuffles the order of the cards in the deck"""
        random.shuffle(self._starting_cards)

    def pick(self, amount=int(1)):
        """(list): returns an amount of cards and removes them from the deck"""
        temp_list = []
        for i in range(amount):
            temp_list.append(self._starting_cards.pop())
        return temp_list

    def add_card(self, card):
        """Adds a card to the Deck"""
        self._starting_cards.append(card)

    def add_cards(self, cards):
        """Adds a list of cards to the cards in the deck"""
        self._starting_cards.extend(cards)

    def copy(self, other_deck):
        """Copies cards from other_deck to this Deck"""
        self.add_cards(other_deck.get_cards())


class Card(object):
    """
    Defines the Card object
    """
    def __repr__(self):
        return "Card()"

    def __str__(self):
        return "Card()"

    def play(self, player, game):
        """
        Defines what happens when a card is played
        Parameters:
            player (Player): The current player
            game (CodersGame): The current CodersGame game
        """
        # Get the index of the current card in the current Deck
        slot = player.get_hand().get_cards().index(self)
        # Remove that card from the Deck
        player.get_hand().remove_card(slot)
        # Pick new card from pickup pile and remove from pile
        new_card = game.get_pickup_pile().pick()[0]
        # Add card to hand
        player.get_hand().add_card(new_card)
        game.set_action("NO_ACTION")

    def action(self, player, game, slot):
        """
        Called when an action of a special card is performed.
        tutor cards - select a coder from the pile,
        keyboard kidnapper and all-nighter cards - select a coder from another players hand.
        (Player) player: the current player
        (CodersGame) game: the current game
        (int) slot: the index of the card to be used
        """
        pass


class NumberCard(Card):
    """
    Defines NumberCard object which is a child of the Card class
    """
    def __init__(self, number):
        """
        (int) number: the number of the NumberCard
        """
        self._number = number

    def __str__(self):
        return "NumberCard(" + str(self._number) + ")"

    def __repr__(self):
        return "NumberCard(" + str(self._number) + ")"

    def get_number(self):
        """:returns (int) the number of the numbercard"""
        return self._number

    def play(self, player, game):
        """Remove old card, pick up new card from pile and place in hand
        set action to NO_ACTION"""
        super(NumberCard, self).play(player, game)
        game.set_action("NO_ACTION")
        game.next_player()

    def action(self, player, game, slot):
        """When a number card is played the game should move to the next players turn"""
        super()


class CoderCard(Card):
    """
    Defines CoderCard object which is a child of the Card class
    """
    def __init__(self, name):
        """
        (str) name: The name of the CoderCard
        """
        self._name = name

    def __str__(self):
        return "CoderCard(" + self._name + ")"

    def __repr__(self):
        return "CoderCard(" + self._name + ")"

    def get_name(self):
        """(str): returns a string of the name of the CoderCard"""
        return self._name

    def play(self, player, game):
        """
        Set game action to "NO_ACTION"
        (Player) player: the current player
        (CodersGame) game: the current game
        """
        # super(CoderCard, self).play(player, game)
        game.set_action("NO_ACTION")


class TutorCard(Card):
    """
    Defines CoderCard object which is a child of the Card class
    """
    def __init__(self, name):
        """
        (str) name: TutorCard's name
        """
        self._name = name

    def __str__(self):
        return "TutorCard(" + self._name + ")"

    def __repr__(self):
        return "TutorCard(" + self._name + ")"

    def get_name(self):
        """(str): returns a string of the name of the TutorCard"""
        return self._name

    def play(self, player, game):
        """Set action to PICKUP_CODER"""
        super(TutorCard, self).play(player, game)
        game.set_action("PICKUP_CODER")

    def action(self, player, game, slot):
        """selected card should be added to the players deck
        replace position of  card in the sleeping coders deck should be with None
        set action to 'NO_ACTION'
        move to the next player"""
        player.get_coders().add_card(game.get_sleeping_coder(slot))
        game.set_sleeping_coder(slot, None)
        game.set_action("NO_ACTION")
        game.next_player()


class KeyboardKidnapperCard(Card):
    """
    Defines KeyboardKidnapperCard object which is a child of the Card class
    """
    def __str__(self):
        return "KeyboardKidnapperCard()"

    def __repr__(self):
        return "KeyboardKidnapperCard()"

    def play(self, player, game):
        """When a keyboard kidnapper card is played the games acton
        should be set to 'STEAL_CODER"""
        super(KeyboardKidnapperCard, self).play(player, game)
        game.set_action("STEAL_CODER")

    def action(self, player, game, slot):
        """The selected card should be added to the current players deck and removed
        from its origin deck, the action should be set back to'NO_ACTION' and the game
         should move to the next player."""
        player.get_coders().add_card((game.next_player().get_coders().get_card(slot)))
        game.set_action("NO_ACTION")


class AllNighterCard(Card):
    """
    Defines AllNighterCard object which is a child of the Card class
    """
    def __str__(self):
        return "AllNighterCard()"

    def __repr__(self):
        return "AllNighterCard()"

    def play(self, player, game):
        """put a coder card from another player back to sleep
            Games acton should be set to 'SLEEP_CODER"""
        super(AllNighterCard, self).play(player, game)
        game.set_action("SLEEP_CODER")

    def action(self, player, game, slot):
        """ the selected card should be added to the first empty slot in the
        coders pile and removed from its origin deck, the action should be
        set back to'NO_ACTION' and the game should move to the next player."""
        game.set_action("NO_ACTION")
        game.next_player()


def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
