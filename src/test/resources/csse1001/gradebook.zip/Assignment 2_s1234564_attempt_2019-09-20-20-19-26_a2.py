#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random

# Write your classes here
class Player:
    """
    Creates player object 
    Parameter: name(str) - Name of player
    """
    
    def __init__(self,name):
        """
        Constructor for Player class

        Parameter: name(str)
        Creates empty list to store Player hand and coder cards"""
        self.name = name
        self.hand = Deck()
        self.coders = Deck()
    
    def get_name(self):
        """
        Returns the name of Player
        """
        return self.name
    
    def get_hand(self):
        """
        Returns the hand of the Player
        """
        return self.hand
    
    def get_coders(self):
        """
        Returns the coders the Player has
        """
        return self.coders
    
    def has_won(self):
        """
        Checks length of coders list. If 4 or more Player wins
        """
        if len(self.coders._cards) >= 4:
            return True
        else:
            return False

    def __str__(self):
        return ('Player({}, {}, {})'.format(self.name,
                self.hand, self.coders))
        
    def __repr__(self):
        return ('Player({}, {}, {})'.format(self.name,
                self.hand, self.coders))
    

class Deck:
    """
    Create Deck class
    Parameter: starting_cards(list) - If given will be constructor with
    list otherwise created with empty list
    """
    
    def __init__(self,starting_cards=None):
        """Constructs Deck

        Parameters: Starting_cards(list) - If not given, deck is created empty
        """
        if starting_cards is None:
            self._cards = []
        else:
            self._cards = starting_cards
        
    def get_cards(self):
        """
        Returns the list of Cards in deck
        """
        return (self._cards)
    
    def get_card(self, slot):
        """
        Returns the Card located at slot in deck
        """
        return self._cards[slot]
    
    def top(self):
        """
        Return the top Card in deck
        """
        return self._cards[-1]
    
    def remove_card(self, slot):
        """
        Removes the Card located at slot in deck
        """
        self._cards.pop(slot)
        
    def get_amount(self):
        """
        Returns the length of the deck
        """
        return len(self._cards)
    
    def shuffle(self):
        """
        Uses random method shuffle to rearrange elements in deck
        """
        random.shuffle(self._cards)
        return
    
    def pick(self,amount=1):
        """
        Returns the amount of cards from the top of deck
        """
        removed=[]
        for i in range(amount):
            removed.append(self._cards.pop())
        return removed
    
    def add_card(self,card):
        """
        Adds card to the top of the deck list
        """
        return self._cards.append(card)
    
    def add_cards(self,card):
        """
        Iterates thorugh card list and appends to top of deck
        """
        for x in card:
            self._cards.append(x)
        return
        
    def copy(self,other_deck):
        """
        Takes list and extends it onto the top of deck
        """
        self._cards.extend(other_deck._cards)
        
        
    def __str__(self):
        printout = ', '.join(f'{i}' for i in self._cards)
        return ('Deck('+printout+')')
    
    def __repr__(self):
        printout = ', '.join(f'{i}' for i in self._cards)
        return ('Deck('+printout+')')
        
    
class Card:
    """
    Create Card class
    """
    def play(self,player,game):
        """
        General play function called when player picks a card

        Parameters:
            player(Player) - The current player
            game(CodersGame) - class from a2_support.py 
        """
        player_slot = player.hand._cards.index(self)
        player.hand.remove_card(player_slot)
        x = player.get_hand().top()
        player.get_hand().add_card(x)
        game.set_action("NO_ACTION")
        game.next_player()
        return
    
    def action(self,player,game,slot):
        """
        To be overridden in Subclasses

        Parameters:
            player(Player) - the current player dependant on set_action()
            game(CodersGame) - the game instance
            slot(int) - Index of card
        """
        pass
        
    
    def __str__(self):
        return ('Card()')
    
    def __repr__(self):
        return ('Card()')

#All classes from here on are child classes to Card
        
class NumberCard(Card):
    """
    Child class of Card
    """
    def __init__(self,number):
        """
        Construct a NumberCard object
        
        Parameters: number(int) - number of card
        """
        self.number = number
        self.name = 'NumberCard'
    
    def get_number(self):
        """
        Returns the number of NumberCard(int)
        """
        return self.number
    
    def play(self,player,game):
        """
        Removes picked card from player's deck and adds new card to player's deck

        Parameters:
            player(Player) - The current Player
            game(CodersGame) - class from a2_support.py
        """
        pickup_deck = game.get_pickup_pile().top()
        card_index = player.hand._cards.index(self)
        player.hand.remove_card(card_index)
        player.hand.add_card(pickup_deck)
        game.get_pickup_pile().remove_card(-1)
        game.set_action("NO_ACTION")
        game.next_player()
        return

    def __str__(self):
        return ('{}({})'.format(self.name,self.number))
    
    def __repr__(self):
        return ('{}({})'.format(self.name,self.number))
    
    
class TutorCard(Card):
    """
    Child class of Card
    """
    def __init__(self,name):
        """
        Construct a Tutorcard object
        
        Parameter: name(str)
        """
        self.name = name
        self.type = 'TutorCard'
        
    def get_name(self):
        """
        Returns the name of Tutorcard
        """
        return self.name

    def play(self,player,game):
        """
        Removes picked card from deck and adds new card

        Parameters:
            player(Player) - The current Player
            game(CodersGame) - class from a2_support.py
        """
        card_index = player.get_hand().get_cards().index(self)
        player.get_hand().remove_card(card_index)
        x = game.get_pickup_pile().pick()
        player.get_hand().add_card(x[0])
        game.set_action("PICKUP_CODER")
        return

    def action(self,player,game,slot):
        """
        Pickup sleeping coder and add to player's coder deck

        Parameters:
            player(Player) - Current player
            game(CodersGame) - Game being played
            slot(int) - Index of deck where sleeping coder was picked
        """
        #Add Coder to Player Coder Deck
        x = game.get_sleeping_coder(slot)
        player.coders.add_card(x)

        #Remove Coder from Game coder deck. Replace with None
        game.set_sleeping_coder(slot,None)
        game.set_action("NO_ACTION")
        game.next_player()
        return
        
    
    def __str__(self):
        return ('{}({})'.format(self.type,self.name))
    
    def __repr__(self):
        return ('{}({})'.format(self.type,self.name))
    
class AllNighterCard(Card):
    """
    Child class of Card
    """
    def __init__(self):
        """
        Construct Card
        Give card general name AllNighterCard
        """
        self.type = 'AllNighterCard'

    def play(self,player,game):
        """
        Removes picked card from deck and adds new card

        Parameters:
            player(Player) - Opposite player
            game(CodersGame) - class from a2_support.py
        """
        pickup_deck = game.get_pickup_pile().top()
        card_index = player.hand._cards.index(self)
        player.hand.remove_card(card_index)
        top_card = player.hand.top()
        player.hand.add_card(pickup_deck)
        game.get_pickup_pile().remove_card(-1)
        game.set_action("SLEEP_CODER")
        return

    def action(self,player,game,slot):
        """
        Takes coder card from player's deck and returns to game's coder deck

        Parameters:
            player(Player) - Opposite player
            game(CodersGame) - class from a2_support.py
            slot(int) - Index of player coder deck where coder was picked
        """
        #Remove CoderCard from Player Coder hand
        stolen_card = player.coders._cards.pop(slot)
        #Add stolen_card back into game coder deck
        return_slot = game.get_sleeping_coders().index(None)
        game.set_sleeping_coder(return_slot,stolen_card)
        game.set_action("NO_ACTION")
        game.next_player()
        return

    def __str__(self):
        return ('{}()'.format(self.type))

    def __repr__(self):
        return ('{}()'.format(self.type))
    
    
class CoderCard(Card):
    """
    Child class of Card
    """
    def __init__(self,name):
        """
        Constructor for CoderCard
        """
        self.name = name
        self.type = 'CoderCard'
        
    def get_name(self):
        """
        Returns the name of the CoderCard
        """
        return self.name

    def play(self,player,game):
        """
        Set game action to NO_ACTION

        Parameters:
            player(Player) - current player
            game(CodersGame) - class from a2_support.py
        """
        game.set_action("NO_ACTION")
        return

    def __str__(self):
        return ('{}({})'.format(self.type,self.name))

    def __repr__(self):
        return ('{}({})'.format(self.type,self.name))
    
    
class KeyboardKidnapperCard(Card):
    """
    Child class of Card
    """
    def __init__(self):
        """
        Constructor for KeyboardKidnapper
        """
        self.type = 'KeyboardKidnapperCard'

    def play(self,player,game):
        """
        Removes picked card from deck and adds new card

        Parameters:
            player(Player) - Opposite player
            game(CodersGame) - class from a2_support.py
        """
        pickup_deck = game.get_pickup_pile().top()
        card_index = player.hand._cards.index(self)
        player.hand.remove_card(card_index)
        top_card = player.hand.top()
        player.hand.add_card(pickup_deck)
        game.get_pickup_pile().remove_card(-1)
        game.set_action("STEAL_CODER")
        return

    def action(self,player,game,slot):
        """
        Takes coder card from player deck and returns to game coder deck

        Parameters:
            player(Player) - Opposite player
            game(CodersGame) - Game being played
            slot(int) - Index of player code deck where coder was picked
        """
        #Remove card from Player hand
        stolen_card = player.coders._cards.pop(slot)

        #Set player to current Player
        player = game.current_player()
        player.get_coders().add_card(stolen_card)
        game.set_action("NO_ACTION")
        game.next_player()
        
    
    def __str__(self):
        return ('{}()'.format(self.type))

    def __repr__(self):
        return ('{}()'.format(self.type))
        
    
def main():
    print("please run gui.py instead")

if __name__ == "__main__":
    main()
