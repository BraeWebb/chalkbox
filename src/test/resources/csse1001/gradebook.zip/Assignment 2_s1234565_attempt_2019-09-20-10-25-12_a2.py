#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""
''''''
import random

class Card:
    """ The base card class """

    def play(self, player, game):
        """
        Remove the played card from the players hand, picks up a new card from pick up pile and sets action
        to be performed

          Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        # Remove played card from players hand
        player.get_hand().get_cards().remove(self)

        # Add new card to hand and remove it from pick up pile
        player.get_hand().add_card(game.get_pickup_pile().get_cards()[-1])
        game.get_pickup_pile().get_cards().pop(-1)

        game.set_action("NO_ACTION")

    def action(self, player, game, slot):
        """ No action associated with base card class """
        pass

    def __str__(self):
        """ Returns the string representation of card """
        return 'Card()'

    def __repr__(self):
        """ Returns the printable representation of card """
        return Card.__str__(self)

class NumberCard(Card):
    """ A card with an associated number whose aim is to be disposed of by the player """
    def __init__(self, number):
        """
        Construct a new number card

          Parameters:
            number (int) : The number to be associated with the new number card
        """
        Card.__init__(self)
        self._number = number

    def get_number(self):
        """
        Returns the number associated with the number card

        Returns:
            (int): The number associated with the number card
        """
        return self._number

    def play(self, player, game):
        """
        Plays the number card, moves the game on to the next players turn

        Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        super().play(player, game)
        game.next_player()

    def action(self, player, game, slot):
        """ No action associated with number card """
        pass

    def __str__(self):
        """
        Returns the string representation of the number card

        Returns:
            (string): The string representation of card
        """
        return 'NumberCard({0})'.format(self._number)


    def __repr__(self):
        """
        Returns the printable representation of the number card

        Returns:
            (string): The printable representation of card
        """
        return NumberCard.__str__(self)


class CoderCard(Card):
    """ A card that stores the name of a coder """

    def __init__(self, name):
        """
        Constructs a new coder card

        Parameters:
            name (str): The coder name to associate with the new card
        """
        Card.__init__(self)
        self._name = name

    def get_name(self):
        """
        Returns the name of a coder card

        Returns:
            (str): the name associated with the coder card
        """
        return self._name

    def play(self, player, game):
        """
        Sets the action for the current game to NO_ACTION

          Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        game.set_action("NO_ACTION")

    def action(self, player, game, slot):
        """ No action associated with number card """
        pass

    def __str__(self):
        """
        Returns the string representation of the number card

        Returns:
            (string): The string representation of card
        """
        return 'CoderCard({0})'.format(self._name)

    def __repr__(self):
        """
        Returns the printable representation of the number card

        Returns:
            (string): The printable representation of card
        """
        return CoderCard.__str__(self)


class TutorCard(Card):
    """ A card that stores the name of a tutor """

    def __init__(self, name):
        """
        Constructs a new tutor card

        Parameters:
            name (str): The tutor name to associate with the new card
        """
        Card.__init__(self)
        self._name = name

    def get_name(self):
        """
        Returns the name of a tutor card

        Returns:
            (str): the name associated with the tutor card
        """
        return self._name

    def play(self, player, game):
        """
         Plays the card and sets the action for the current game to PICKUP_CODER

          Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        super().play(player, game)

        game.set_action("PICKUP_CODER")

    def action(self, player, game, slot):
        """
        Adds a chosen sleeping coder card to the players hand, replaces the chosen sleeping coder card with
        None and resets the action to NO_ACTION and moves onto the next player

          Parameters:
            game (CodersGame) : The current game of sleeping coders
            player (Player): The current player
            slot (int): The index in the sleeping coders list the chosen card occupies
        """
        # Selected card added to players deck
        chosen_card = game.get_sleeping_coders()[slot]
        player.get_coders().add_card(chosen_card)

        # Chosen sleeping coder position replaced with none
        game.get_sleeping_coders().pop(slot)
        game.get_sleeping_coders().insert(slot, None)

        game.set_action("NO_ACTION")
        game.next_player()

    def __str__(self):
        """
        Returns the string representation of the tutor card

        Returns:
            (string): The string representation of tutor card
        """
        return 'TutorCard({0})'.format(self._name)

    def __repr__(self):
        """
        Returns the printable representation of the tutor card

        Returns:
            (string): The printable representation of tutor card
        """
        return TutorCard.__str__(self)

class CoderActionCard(Card):
    """ A class of card which involves interacting with a players coder cards """

    def end_action(self, game, player, slot):
        """
        Removes a selected coder card from a players coder deck, sets games action back
        to NO_ACTION and moves game onto the next players.

        Parameters:
            game (CodersGame) : The current game of sleeping coders
            player (Player): The player of the card
            slot (int): The index of the coder to be removed from the players coder deck
        """
        player.get_coders().remove_card(slot)
        game.set_action("NO_ACTION")
        game.next_player()


class KeyboardKidnapperCard(CoderActionCard):
    """ A card which, when played, allows the player to steal a coder card from another player """

    def __init__(self):
        """ Constructs a new Keyboard Kidnapper Card """
        Card.__init__(self)

    def play(self, player, game):
        """
        Plays the card and sets the action for the current game to STEAL_CODER

          Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        super().play(player, game)

        game.set_action("STEAL_CODER")


    def action(self, player, game, slot):
        """
        Adds a chosen active coder card to the players hand, removes the chosen coder card from its original
        deck. resets the action to NO_ACTION and moves onto the next player

          Parameters:
            game (CodersGame) : The current game of sleeping coders
            player (Player): The player whose coder has been selected
            slot (int): The index in the coder deck the chosen coder occupies
        """
        # Chose card and add it to current players deck
        chosen_card = player.get_coders().get_card(slot)
        game.current_player().get_coders().add_card(chosen_card)

        super().end_action(game, player, slot)

    def __str__(self):
        """
        Returns the string representation of the keyboard kidnapper card

        Returns:
            (string): The string representation of keyboard kidnapper card
        """
        return 'KeyboardKidnapperCard()'

    def __repr__(self):
        """
        Returns the printable representation of the keyboard kidnapper card

        Returns:
            (string): The printable representation of keyboard kidnapper card
        """
        return KeyboardKidnapperCard.__str__(self)

class AllNighterCard(CoderActionCard):
    """ A card which, when played, allows the player to put a coder card from another player back to sleep. """

    def __init__(self):
        """ Constructs a new All Nighter Card """
        Card.__init__(self)

    def play(self, player, game):
        """
         Plays the card and sets the action for the current game to SLEEP_CODER

          Parameters:
            player (Player): The player of the card.
            game (CodersGame) : The current game of sleeping coders
        """
        super().play(player, game)

        game.set_action("SLEEP_CODER")

    def action(self, player, game, slot):
        """
        Adds a chosen active coder card back to the first empty slot in the sleeping coders list, removes the
        chosen coder card from its original deck. Resets the action to NO_ACTION and moves onto the next player.

          Parameters:
            game (CodersGame) : The current game of sleeping coders
            player (Player): The player whose coder has been selected
            slot (int): The index in the coder deck the chosen coder occupies
        """

        # Get index of first None in sleeping coders list and removes it
        first_empty_coder_slot = game.get_sleeping_coders().index(None)
        game.get_sleeping_coders().pop(first_empty_coder_slot)

        # Replace empty slot with chosen card
        chosen_card = player.get_coders().get_card(slot)
        game.get_sleeping_coders().insert(first_empty_coder_slot, chosen_card)

        super().end_action(game, player, slot)

    def __str__(self):
        """
        Returns the string representation of the all nighter card

        Returns:
            (string): The string representation of all nighter card
        """
        return 'AllNighterCard()'

    def __repr__(self):
        """
        Returns the printable representation of the all nighter card

        Returns:
            (string): The printable representation of all nighter card
        """
        return AllNighterCard.__str__(self)

class Deck:
    """ A class which represents a collection of ordered cards """

    def __init__(self, starting_cards=None):
        """
        Constructs a deck cards provided, if none provided creates an empty deck

        Parameters:
            starting cards(list): The list of cards the deck should be constructed with
        """
        if starting_cards is None:
            self._cards = []
        else:
            self._cards = starting_cards

    def get_cards(self):
        """
        Returns the list of cards in the deck

        Returns:
            (list): The list of cards in the deck
        """
        return self._cards

    def get_card(self, slot):
        """
        Returns the card at the specified slot in the deck

        Parameters:
            slot(int): The slot in the deck specified

        Returns:
            (Card): The Card occupying the specified slot
        """
        return self._cards[slot]

    def top(self):
        """
        Returns the card on the top of the deck (the last card added to that deck)

        Returns:
            (Card): the last card added to the deck
        """
        return self._cards[-1]

    def remove_card(self, slot):
        """
        Removes a card at the specified slot in the deck

        Parameters:
            slot(int): The slot in the deck specified
        """
        del self._cards[slot]

    def get_amount(self):
        """
        Returns the number of cards in the deck

        Returns:
            (int): the number of cards in the deck
        """
        return len(self._cards)

    def shuffle(self):
        """ Shuffles the order of cards in the deck """
        random.shuffle(self._cards)

    def pick(self, amount=1):
        """
        Returns the specified amount of cards off the top of the deck as a list, removes those cards from the
        deck

        Parameters:
            amount(int): The number of cards to pick from the top of the deck

        Returns:
            pick_list(list<Card>): the list of cards picked off the top of deck
        """
        pick_list = []

        while amount > 0:
            pick_list.append(self.top())
            self.get_cards().pop(-1)
            amount -= 1

        return pick_list

    def add_card(self, card):
        """
        Placed a card on top of the deck

        Parameters:
            card(Card): The card to add to the deck
        """
        self._cards.extend([card])

    def add_cards(self, cards):
        """
        Places a list of cards on top of the deck

        Parameters:
            cards(List<Card>): The list of cards to be added to the deck
        """
        self._cards.extend(cards)

    def copy(self, other_deck):
        """
       Copies all the cards of a given deck into the current deck

        Parameters:
            other_deck(Deck): The given deck to add to the current deck
        """
        self.add_cards(other_deck.get_cards())

    def __str__(self):
        """
        Returns the string representation of the deck

        Returns:
            (string): The string representation of the deck
        """
        return 'Deck({0})'.format(str(self._cards).strip('[]'))

    def __repr__(self):
        """
        Returns the printable representation of the deck

        Returns:
            (string): The printable representation of the deck
        """
        return Deck.__str__(self)

class Player:
    """ A player within a game of sleeping coders """

    def __init__(self, name):
        """
        Constructs a player with a given name

        Parameters:
            name(str): The name associated with the player
        """
        self._name = name
        self._hand = Deck()
        self._coders = Deck()

    def get_name(self):
        """
        Returns the name of a player

        Returns:
            (str): the name associated with the player
        """
        return self._name

    def get_hand(self):
        """
        Returns the players hand of cards

        Returns:
            (Deck): The deck of cards in the players hand
        """
        return self._hand

    def get_coders(self):
        """
        Returns the players deck of collected coder cards

        Returns:
            (Deck): The deck of collected coder cards
        """
        return self._coders

    def has_won(self):
        """
        Returns True if and only if the player has 4 or more coders

        Returns:
            (bool): Whether the player has won or not
        """
        if self._coders.get_amount() >= 4:
            return True
        else:
            return False

    def __str__(self):
        """
        Returns the string representation of the player along with their hand and coders

        Returns:
            (string): The string representation of the player along with their hand and coders
        """
        return 'Player({0}, {1}, {2})'.format(self._name, self._hand, self._coders)

    def __repr__(self):
        """
        Returns the printable representation of the player along with their hand and coders

        Returns:
            (string): The sprintable representation of the player along with their hand and coders
        """
        return Player.__str__(self)


def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
