#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""
import random
from a2_support import *

# Write your classes here

class card(object):
    '''
    Base class for all cards
    '''

    def __init__(self):
        pass

    def __str__(self):
        return 'Card()'

    def __repr__(self):
        return 'Card()'

    def play(self, player: play, game: play.CodersGame):
        return -1

    def action(self, player: play, Game: play.CodersGame):
        return -1


def number(args):
    pass


def number(args):
    pass


class NumberCard(card):
    '''
    Number card for game of sleeping coders
    '''

    def __init__(self, number):
        super().__init__()
        self._number = number

    def get_number(self):
        '''
        Returns number value of card

        Parameters:
            Output (int): value of card
        '''
        return self._number

    def __str__(self):
        '''
        Overwrites the str method of the superclass

        Parameters:
            Output (str): numbercard name and number
        '''
        return 'NumberCard(' + str(number) + ')'

    def __repr__(self):
        '''
        Overwrites the repr method of the superclass

        Parameters:
            Output (str): numbercard name and number
        '''
        return 'NumberCard(' + str(number) + ')'


class CoderCard(card):
    '''
    Coder card for game of sleeping coders
    '''

    def __init__(self, name):
        super().__init__()
        self._name = name

    def get_name(self):
        '''
        Method for checking coder name
        Parameters:
            Output (str): coder name
        '''
        return self._name


class TutorCard(card):
    def __init__(self, name):
        super().__init__()
        self._name = name

    def __str__(self):
        '''
        Overwrites the str method of the superclass

        Parameters:
            Output (str): card name
        '''
        return 'TutorCard(' + str(self._name) + ')'

    def __repr__(self):
        '''
        Overwrites the repr method of the superclass

        Parameters:
            Output (str): card name
        '''
        return 'TutorCard('+str(self._name)+')'

    def play(self, player: play, game: play.CodersGame):
        return -1


class KeyboardKidnapperCard(card):
    '''
    KeyboardKidnapper card for game of sleeping coders
    '''
    #def play(self, player: play, game: play.CodersGame):
    #    return -1

    def __str__(self):
        '''
        Overwrites the str method of the superclass

        Parameters:
            Output (str): card type
        '''
        return 'KeyboardKidnapperCard()'

    def __repr__(self):
        '''
        Overwrites the repr method of the superclass

        Parameters:
            Output (str): card type
        '''
        return 'KeyboardKidnapperCard()'


class AllNighterCard(card):

    '''
    AllNighter card for game of sleeping coders
    '''

   # def play(self, player: play, game: play.CodersGame):
      #  return -1

    def __str__(self):
        '''
        Overwrites the str method of the superclass

        Parameters:
            Output (str): card type
        '''
        return 'AllNighterCard()'

    def __repr__(self):
        '''
        Overwrites the repr method of the superclass

        Parameters:
            Output (str): card type
        '''
        return 'AllNighterCard()'


def shuffle(_cards):
    pass


class Deck(object):
    '''
    A deck of cards for sleeping coders
    '''

    def __int__(self, starting_cards=None):
        self._cards = starting_cards

    def get_cards(self):
        '''
        Method to get all card in deck
        '''

        return self._cards

    def get_card(self, slot):
        '''
        Method to get card in slot

        Parameters:
             slot (int): index of card
        '''

        return self._cards[slot]

    def top(self):
        '''
        Method to get last card added to deck.
        '''
        return self._cards[0]

    def remove_card(self, slot):
        '''
        Method to remove card in slot

        Parameters:
            slot (int): index of card to remove
        '''

        self._cards.pop(slot)

    def get_amount(self):
        '''
        Method to get size of deck

        Parameters:
             Output(int): number of cards in deck
        '''

        return len(self._cards)

    def shuffle(self):
        '''
        Method to randomly reorder deck
        '''
        shuffle(self._cards)

    def pick(self, amount: int = 1):
        '''
        Method to pick a card off top of deck

        Parameters:
            amount (int): number of cards to pick
            Output(list): list of cards drawn
        '''

        picked = []
        counter = 0
        while counter < amount:  # iterates through deck and appends required cards to new list
            picked.append(self._cards[counter])
            counter += 1
        return picked

    def add_card(self, card: top):
        '''
        Method to add a card to top of deck

        Parameters:
            card(Card): card to be added
        '''
        self._cards.insert(0, card)

    def add_cards(self, cards: __str__[top]):
        '''
        Method to add cards to top of deck

        Parameters:
            cards (List(Card)): cards to be added
        '''
        reversed_list = cards.reverse()
        for card in reversed_list:
            self._cards.insert(0, card)

    def copy(self, other_deck: pick):
        '''
        Method to add another deck of cards into the deck

        Parameters:
            other_deck (Deck): deck to be added
        '''
        self._cards.extend(other_deck)


    def __repr__(self):
        '''
        Repr method to describe deck

        Parameters:
            Output (str): str listing deck elements
        '''
        ele_str_list = []
        for element in self._cards:
            ele_str_list.append(element.__str__())
        deck_str = ','.join(ele_str_list)
        return 'Deck('+deck_str+')'

    def __str__(self):
        '''
        Str method to describe deck

        Parameters:
            Output (str): str listing deck elements
        '''
        ele_str_list = []
        for element in self._cards:
            ele_str_list.append(element.__str__())
        deck_str = ','.join(ele_str_list)
        return 'Deck(' + deck_str + ')'

class Player(object):
    '''
    The player for a game of sleeping coders
    '''
    def __init__(self, name):
        '''

        Parameters:
            hand (Deck): deck of cards
            name(str): player name
            coders(Deck): deck of coders
        '''

        self._hand = Deck()
        self._name = name
        self._coders = Deck()

    def get_name(self):
        '''
        Method for getting player name

        Parameters:
            Output (str): player name
        '''
        return self._name

    def get_hand(self):
        '''
        Method for getting players' deck

        Parameters:
            Output(Deck): deck of cards (may be empty)
        '''
        return self._hand.get_cards()

    def get_coders(self):
        '''
        Method for getting collected coders

        Parameters:
             Output (Deck): deck of coder cards
        '''
        return self._coders.get_cards()

    def has_won(self):
        '''
        Method for checking if player has met win condition

        Parameters:
             Output(Boolean): True if won, False if not yet won
        '''
        if self._coders.get_amount() > 3:
            return True
        else:
            return False

    def __repr__(self):
        '''
        repr method to represent class

        Parameters:
             Output (str): Player name and decks
        '''
        return '{0},{1},{2}'.format(self._name, self._hand.__str__(), self._coders.__str__())

def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()
