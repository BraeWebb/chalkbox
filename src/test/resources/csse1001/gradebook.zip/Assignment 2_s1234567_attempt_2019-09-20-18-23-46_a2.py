#!/usr/bin/env python3


import random

# Write your classes here

class Card(object):
    """The base card class with methods for playing a card and performing a card action."""        
    def play(self, player, game):
        """Called when a player plays card. If no action needs to be performed,
           set the action.
           
        Parameters:
            player: (Player) in the game.
            game: a2 support file CodersGame.
        """    
        player.get_hand().remove_card()
        player.get_card()
        game.set_action('NO_ACTION') 


    def action(self, player, game, slot):
        """Called when an action of a special card is performed.

        Parameters:
            player:(Player) in the game.
            game: a2 support file CodersGame.
            slot (int): The slot within the collection to set card.
        """    
        game.set_action('NO_ACTION')

    def __str__(self):
        return 'Card()'

    def __repr__(self):
        return str(self)    


class NumberCard(Card):
    """A class for the number card i.e. NumberCard(number),
       whose aim is to be disposed of by the player.
       A number card has an associated number value.
       
    Parameters:
         (int): number value of card.    
    """
    def __init__(self, number):
        """Constructor initialises instance of class."""
        self._number = number

    def get_number(self):
        """Returns the number value of the card."""
        return self._number
        
    def __str__(self):
        return 'NumberCard({0})'.format(self._number)

    def __repr__(self):
        return str(self)

    
class CoderCard(Card):
    """A class for coder card i.e. CoderCard(name).
       A card which stores the name of a coder card.

    Parameters:
       (str): name of the card.   
    """
    def __init__(self, name):
        """Constructor: initialises instance of coder card."""
        self._name = name

    def get_name(self):
        """Returns the card name."""
        return self._name

    def play(self, game):
        """Called when a player plays a card."""
        game.set_action('NO_ACTION')

    def action(self, game):
        """Called when an action of a special card is performed."""
        game.set_action('NO_ACTION')
        
    def __str__(self):
        return 'CoderCard({0})'.format(self._name)

    def __repr__(self):
        return str(self)


class TutorCard(Card):
    """A class for the tutor card i.e. TutorCard(name).
       A card which stores the name of a tutor card.
       
    Parameters:
       (str): name of the card.      

   """
    def __init__(self, name):
        """Constructor: initialises instance of tutor card. """
        self._name = name

    def get_name(self):
        """Returns the card name."""
        return self._name    
   
    def play(self, game):
        """Called when a player plays a card."""
        game.set_action('PICKUP_CODER')

    def action(self, game):
        """Called when an action of a special card is performed."""
        game.set_action('NO_ACTION')
       
    def __str__(self):
        return 'TutorCard({0})'.format(self._name)

    def __repr__(self):
        return str(self)


class KeyboardKidnapperCard(Card):
    """A card which allows the player to steal a coder card
       from another player.

       When played the games action set to 'STEAL_CODER'.
    """ 
    def play(self, game):
        """Called when a player plays a card."""
        game.set_action('STEAL_CODER')

    def action(self, game):
        """Called when an action of a special card is performed."""
        game.set_action('NO_ACTION')
         
    def __str__(self):
        return 'KeyboardKidnapperCard()'

    def __repr__(self):
        return str(self)
    

class AllNighterCard(Card):
    """A card which allows the player to put a coder card from
       another player back to sleep.
       
       When played the games action set to 'SLEEP_CODER'.
    """    
    def play(self, game):
        """Called when a player plays a card."""
        game.set_action('SLEEP_CODER')

    def action(self, game):
        """Called when an action of a special card is performed."""
        game.set_action('NO_ACTION')

    def __str__(self):
        return 'AllNighterCard()'

    def __repr__(self):
        return str(self)    
    

    
class Deck(object):
    """A class for Deck, a collection of ordered cards.
       When starting_deck is None, creates an empty list=[].
       
    Parameters:
        (List[Card]): if cards provided, creates list of cards as starting_cards.   
    """
    def __init__(self, starting_cards = None):
        """Constructor: initialises the deck of cards."""
        if starting_cards is None:
            self._cards = []
        else:
            self._cards = starting_cards

    def get_cards(self):
        """Returns a list of cards in the deck."""
        return self._cards

    def get_card(self, slot):
        """Returns the card at the specified slot in a deck."""
        return self._cards[slot]

    def remove_card(self, slot):
        """Removes a card at given slot."""
        self._cards.pop(slot)

    def top(self):
        """Returns the top card in deck."""
        return self._cards[-1]

    def get_amount(self):
        """Returns the amount of cards in deck."""
        return len(self._cards)

    def shuffle(self):
        """Shuffles the order of the cards in the deck."""
        random.shuffle(self._cards)

    def pick(self, amount):
        """Returns the first 'amount' of cards off the deck."""
        return amount
     
    def add_card(self, card):
        """Places a card on top of the deck."""
        self._cards.append(card)

    def add_cards(self, cards):
        """Places a list of cards on top of the deck."""
        self._cards = self._cards + list(cards)

    def copy(self, other_deck):
        """: Copies all of the cards from the other_deck into the current deck."""
        
         
    def __str__(self):
        """Returns the string representation of the deck."""
        result = []
        for card in self._cards:
            result.append(str(card))
        return 'Deck(' + "".join(result) + ')'
  
    def __repr__(self):
        return str(self)   


class Player(object):
    """A class for Player.  A player represents one of the players in the game.
       The Player class should be initiated with Player(name).

    Parameters:
        (str): name of the player instance.
    """
    def __init__(self, name):
        """Constructor: initialises the Player instance."""
        self._name = name
        self._hand = Deck()
        self._coders = self._hand
        
    def get_name(self):
        """Returns name of player."""
        return self._name

    def get_hand(self):
        """Returns the players deck of cards."""
        return self._hand

    def get_coders(self):
        """Returns the players deck of collected coder cards."""
        return self._coders

    def has_won(self):
        """ (bool): Returns True if four or more CoderCards collected."""
        amount = get_amount()
        if self._coders.amount >= 4:
            return True
        else:
            return False
     
    def __str__(self):
        return 'Player({0}, {1}, {2})'.format(self._name,
                                              self._hand,
                                              self._coders)
    def __repr__(self):
        return str(self)    

def main():
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()



