#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

import random


# Write your classes here
class Player(object):
    """A Player object.
    """

    def __init__(self, name):
        """Constructs a Player with name as an argument.
            Initialises hand and coders as an empty deck.

        Parameter: name (str)
        hand (Deck)
        coders (Deck)
        """
        self._name = name
        self._hand = Deck()
        self._coders = Deck()

    def get_name(self):
        """Function returns the player's name (str)
        """
        return self._name

    def get_hand(self):
        """Function returns the player's hand (Deck)
        """
        return self._hand

    def get_coders(self):
        """Function returns the player's coders (deck)
        """
        return self._coders

    def has_won(self):
        """Function returns True (Boolean) if coder cards in hand are greater or equal than 4
        """
        if self.get_coders().get_amount() >= 4:
            return True
        else:
            return False

    def __str__(self):
        """Return string of Player object: Player(str), Name(str), Hand(Deck: List), Coders (Deck: List)
        """
        return "Player({0}, {1}, {2})".format(self._name, self._hand, self._coders)

    def __repr__(self):
        """Return string of Player object: Player(str), Name(str), Hand(Deck: List), Coders (Deck: List)
        """
        return "Player({0}, {1}, {2})".format(self._name, self._hand, self._coders)


class Deck(object):
    """A Deck object.
    """

    def __init__(self, starting_cards=None):
        """Constructs a deck with a list of cards as an argument.
        Unless an argument is provided, starting_cards is initialised with an empty list.
        """
        if starting_cards is None:
            self._starting_cards = []
        else:
            self._starting_cards = starting_cards

    def get_cards(self):
        """Function GETS the list of cards as determined by starting_deck
        """
        return self._starting_cards

    def get_card(self, slot: int):
        """Function returns card at specified index (determined by slot) in a deck
        """
        return self.get_cards()[slot]

    def top(self):
        """Function returns card at the top of deck (or at the end of a list).
        """
        return self.get_cards()[-1]

    def remove_card(self, slot: int):
        """Function removes card at given slot in a deck.
        """
        self.get_cards().pop(slot)

    def get_amount(self):
        """Function returns length (int) of a list e.g. the number of cards in a deck.
        """
        return len(self.get_cards())

    def shuffle(self):
        """Function shuffles the order of items in a list e.g. the order of cards in a deck.
        """
        random.shuffle(self.get_cards())

    def pick(self, amount=1):
        """Function returns and removes a number of cards of the top off the deck, as determined by
            amount argument. Be default set to 1.

            Parameter: amount (int)
            Return: List[Card]
        """
        temp = []
        for i in range(amount):
            temp.append(self.top())
            self.remove_card(-1)
        return temp

    def add_card(self, card):
        """adds a card on top of the deck
        """
        self.get_cards().append(card)

    def add_cards(self, cards: list):
        """adds a list of cards on top of the deck
        """
        self.get_cards().extend(cards)

    def copy(self, other_deck):
        """extend the list of cards from other_deck to current deck
        """
        deck = self.get_cards()
        other_deck = other_deck.get_cards()
        self._starting_cards = deck + other_deck

    def __str__(self):
        deck = self.get_cards()
        str1 = ', '.join(str(i) for i in deck)
        return "Deck({0})".format(str1)

    def __repr__(self):
        deck = self.get_cards()
        str1 = ', '.join(str(i) for i in deck)
        return "Deck({0})".format(str1)

    '''def __str__(self):
        strdeck = str(self.get_cards())
        strdeck = strdeck.strip('[')
        strdeck = strdeck.strip(']')
        return "Deck({0})".format(strdeck)
    '''


class Card(object):
    """Construct a card object
    """

    def __init__(self):
        """Construct a card object.
        """

    def play(self, player, game):
        """ Player plays a card.
            Card removed from Player's hand.
            Player picks up a card from pickup pile.
            Action for card is set
        """
        player.get_hand().remove_card(player.get_hand().get_cards().index(self))
        player.get_hand().add_cards(game.get_pickup_pile().pick())
        game.set_action('NO_ACTION')


    def action(self, player, game, slot: int):
        """Called when an action of a special card is performed
        """
        #Child classes will override this
        pass


    def __str__(self):
        """returns string of Card()
        """
        return "Card()"

    def __repr__(self):
        """returns string of Card()
        """
        return "Card()"


class NumberCard(Card):
    """NumberCard object, subclass of Card
    """

    def __init__(self, number):
        """Construct a subclass of Card that takes number (int) as an argument.
        """
        self._number = number

    def get_number(self):
        """Return number (int)
        """
        return self._number

    def play(self, player, game):
        """inherits the function play from number card, and calls number card
        """
        super().play(player, game)
        game.next_player()

    def __str__(self):
        """returns NumberCard string.
        """
        return "NumberCard({0})".format(self._number)

    def __repr__(self):
        """returns NumberCard string.
        """
        return "NumberCard({0})".format(self._number)


class CoderCard(Card):
    """CoderCard subclass of Card
    """

    def __init__(self, name):
        """constructs a subclass of card with name as argument
        """
        self._name = name

    def get_name(self):
        """returns name.
        """
        return self._name

    def play(self, player, game):
        """Sets player action to 'no action'
        """
        game.set_action('NO_ACTION')


    def __str__(self):
        """returns string of CoderCard
        """
        return "CoderCard({0})".format(self._name)

    def __repr__(self):
        """returns string of CoderCard
        """
        return "CoderCard({0})".format(self._name)


class TutorCard(Card):
    """Creates a TutorCard object, subclass of Card
    """

    def __init__(self, name):
        """Construct a TutorCard, with name as an argument
        """
        self._name = name

    def get_name(self):
        """returns name.
        """
        return self._name

    def play(self, player, game):
        """inherits Card's play function and sets action to 'pickup coder'
        """
        super().play(player, game)
        game.set_action('PICKUP_CODER')


    def action(self, player, game, slot):
        """Select a sleeping coder.
        Adds it to players coders pile.
        calls next turn.
        """
        player.get_coders().add_card(game.get_sleeping_coder(slot))
        game.set_sleeping_coder(slot, card=None)
        game.set_action('NO_ACTION')
        game.next_player()

    def __str__(self):
        """returns tutorcard string
        """
        return "TutorCard({0})".format(self._name)

    def __repr__(self):
        """returns tutorcard string
        """
        return "TutorCard({0})".format(self._name)


class AllNighterCard(Card):
    """Construct an AllNighterCard, subclass of Card
    """

    def __init__(self):
        """

        """
        self._action = None

    def play(self, player, game):
        """function inherits play function from Card allnightercard and sets action to 'sleep coder'
        """
        super().play(player, game)
        game.set_action('SLEEP_CODER')

    def action(self, player, game, slot: int):
        """function puts another players coder back to sleep.
        """

        game.set_sleeping_coder(game.get_sleeping_coders().index(None), player.get_coders().get_card(slot))
        player.get_coders().remove_card(slot)
        game.set_action('NO_ACTION')
        game.next_player()

    def __str__(self):
        """returns allnightercard string.
        """
        return "AllNighterCard({0})".format('')

    def __repr__(self):
        """returns allnightercard string.
        """
        return "AllNighterCard({0})".format('')


class KeyboardKidnapperCard(Card):
    """Creates a KeyboardKidnapperCard object, subclass of Card
    """

    def __init__(self):
        """Construct a KeyboardKidnapperCard, subclass of Card
        """

    def play(self, player, game):
        """function inherits play function from Card. sets action to 'steal coder'.
        """
        super().play(player, game)
        game.set_action('STEAL_CODER')

    def action(self, player, game, slot: int):
        """removes a codercard from apposing player, and places it within current_players deck.
        """
        game.current_player().get_coders().add_card(player.get_coders().get_card(slot))
        player.get_coders().remove_card(slot)
        game.set_action('NO_ACTION')
        game.next_player()

    def __str__(self):
        """returns keyboardkidnapper string.

        :return:
        """
        return "KeyboardKidnapperCard({0})".format('')

    def __repr__(self):
        """returns keyboardkidnapper string.
        """
        return "KeyboardKidnapperCard({0})".format('')



def main():
    """

    :return:
    """
    print("Please run gui.py instead")


if __name__ == "__main__":
    main()


