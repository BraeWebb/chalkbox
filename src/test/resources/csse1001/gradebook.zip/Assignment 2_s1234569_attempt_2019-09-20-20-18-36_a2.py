#!/usr/bin/env python3
"""
Assignment 2 - Sleeping Coders
CSSE1001/7030
Semester 2, 2019
"""

## Notes ##
#write classes for card, deck and player 

import random

# Write your classes here

def main():
    print("Please run gui.py instead")

if __name__ == "__main__":
    main()

                                ### Classes ###
class Card(object):
    """ Constructor for class
    """
    def __init__(self):
        pass
    
    """String represenation"""
    def __str__(self):
        return 'Card()'

    """Represents the string"""
    def __repr__(self):
        return 'Card()'
    
    def play(self, player, game): #complete this
        return None

    def action(self, player, game): #hardcode in action
        pass
    
""" Following cards are subclasses of parent class 'Card' """

""" NumberCard """
class NumberCard(Card):
    def __init__(self,number):
        self._number = number
        
    def get_number(self):
        return self._number

    def __str__(self):
        return 'NumberCard({})'.format(self.get_number())

    def __repr__(self):
        return 'NumberCard({})'.format(self.get_number())
    
"""CoderCard"""
class CoderCard(Card):
    def __init__(self,name):
        self._name = name
        
    def get_name(self):
        return self._name

    def __str__(self):
        return 'CoderCard({})'.format(self.get_name())

    def __repr__(self):
        return 'CoderCard({})'.format(self.get_name())

    
"""TutorCard"""
class TutorCard(Card):
    def __init__(self,name):
        self._name = name

    def get_name(self):
        return self._name

    def __str__(self):
        return 'TutorCard({})'. format(self.get_name())

    def __repr__(self):
        return 'TutorCard({})'. format(self.get_name())
 
##        #action: PICKUP_CODER
##        #when tutor card is performed, slected card should be added to players deck, position oft he card in the sleeping coders' deck should be replaced with NONE
##        #action:NO_ACTION and the game should move onto the next player
##        def get_name(self): #string returns the card name

    
"""KeyboardKidnapperCard"""        
class KeyboardKidnapperCard(Card):
    def __str__(self):
        return 'KeyboardKidnapperCard()'

    def __repr__(self):
        return 'KeyboardKidnapperCard()'

##    #action: STEAL_CODER
##    #selected card should be added to the current player's deck and removed form its origin deck
##    #action: NO_ACTION and the game should move onto the next player
##
"""AllNighterCard""" 
class AllNighterCard(Card):
    def __str__(self):
        return 'AllNighterCard()'

    def __repr__(self):
        return 'AllNighterCard()'
##
##    #allows player to put a coder card from another player back to sleep
##    #action: SLEEP_CODER
##
class Deck(object):
    def __init__(self,starting_cards=None):
        """ Constructor: initialises Deck to be empty
            When index is None: empty list
            Otherwise, = starting_cards
        """
        if starting_cards == None:
            self._deck = []
        else:
            self._deck = starting_cards

    
### works up to here - from hereon, just my attempts
            
    def get_cards(self):
        """ return string of cards .. hopefully"""
        return build_deck(self._cards)

    def get_card(self,slot):
        """ creates an index """ 
        return self._cards[slot]

    def top(self):
        """returns card on top of deck - essentially a draw"""
        return pick_card(self._cards) 

    def remove_card(self, slot):
        return self.cards.remove(slot)

    def get_amount(self):
        return self.cards

    def shuffle(self):
        random.shuffle(self.cards)
    
##
##    #def pick(self, ##what?? = number)
##        #return list[0:number]
##
    def add_card(self, card):
        self.cards.apppend(card) 

    def add_cards(self, cards):
        self.cards.append(self._cards)
        return 
    def copy(self, other_deck):
        return None

    def pick(self,thing):
        return None

    
    def __str__(self):
        return 'Deck({Cards})'

    def __repr__(self):
        return 'Deck({Cards})'
##
    #__str__self() #returns the string representation of the deck, for a deck which contains cardA, cardB and cardC
    #this should give Deck(cardA, cardB, cardC)
    #__repr__(self) #same as __str__(self)
            

class Player: 
    def __init__(self,name):
        self.name = name
        
    def get_name(self): #returns string of the name of the player
        #self.name = name
        return self.name

    def get_hand(self): #Deck -> returns the players deck of cards
        return None

    def get_coders(self): #Deck -> returns the players deck of collected coder cards
        return None

    def has_won(self):#Bool - returns true if and only if the player has 4 or more coders
        """ Boolean function:
            True - ONLY if the player has >=4 coder cards
            False - if the players have less than <4 coder cards
            """
       #see possibily maddy's example
##        
##    #__str__(self) #returns the string represenation of the player, for a player named __, hand deck of 'hand'
##    # and coder deck of 'coders', this should be 'Player(___,hand,coders)'
##    #__repr__(self) #same as above
##
###go through a2.support (game class and turn manager)
###def action():
##
##    
##NOTES TO SELF:
        ##number_cards = len(self.cards) #number of cards left
##        import random #random range of cards
##        for a in range(number_cards):
##            b = random.randrange(a,number_cards)
##            self.cards[a], self.cards[b] = self.cards[a]. self.cards[b] #use of tuple assignment 
####    
##    
##
##
##
##
##
